function cevapVer(cevap) {
    if (cevap === 'evet') {
        window.location.href = 'seviyorum.html';
    }
}

function getRandomPosition() {
    // Sayfa genişliği ve yüksekliği alınıyor
    var pageWidth = window.innerWidth;
    var pageHeight = window.innerHeight;

    // Butonun genişliği ve yüksekliği alınıyor
    var buttonWidth = document.getElementById('hayir').offsetWidth;
    var buttonHeight = document.getElementById('hayir').offsetHeight;

    // Rastgele x ve y koordinatları oluşturuluyor
    var randomX = Math.floor(Math.random() * (pageWidth - buttonWidth));
    var randomY = Math.floor(Math.random() * (pageHeight - buttonHeight));

    return [randomX, randomY];
}

function cevapVer(cevap) {
    if (cevap === 'evet') {
        window.location.href = 'seviyorum.html';
    } else if (cevap === 'hayir') {
        var [x, y] = getRandomPosition();
        document.getElementById('hayir').style.position = 'absolute';
        document.getElementById('hayir').style.left = x + 'px';
        document.getElementById('hayir').style.top = y + 'px';
    }
}
